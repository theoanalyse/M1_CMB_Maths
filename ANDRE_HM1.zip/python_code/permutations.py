"""
Made with love (and very late in the night) by Théo André
"""

import numpy as np
import os
import itertools

# Will not work if you do not enter the absolute path of the file
# proper to YOUR computer.

dirname = os.path.dirname(__file__)

path1 = os.path.join(dirname, 'G1.txt')
path2 = os.path.join(dirname, 'G2.txt')

mat1 = np.loadtxt(path1)
mat2 = np.loadtxt(path2)

# get the shape of the matrix (only n is interesting here)
n, p = np.shape(mat1)

# generate all permutations of S_n (might take some time for large n i.e. n > 12)
perms = list(itertools.permutations([i for i in range(1, n+1)]))

# for each permutation, build associated permutation matrix
# and test if mat1 is conjugated to mat2
tests = []
for perm in perms:
    print(perm)
    pmat = np.zeros((n,n))
    for i in range(n):
            pmat[i, perm[i]-1] = 1
    mat = pmat @ mat1 @ pmat.T
    tests.append((np.array_equal(mat, mat2), perm))

# If indeed, mat1 is conjugated to mat2, display all possible permutations
for test in tests:
    bool, perm = test
    if bool == True:
        print("\n possible isomorphism =", perm)

# Otherwise, print that nothing has been found
count = 0
for bool, test in tests:
    if bool == True:
        count += 1

if count == 0:
    print("\nNo isomorphism found")

# thank you for reading my code sir :)